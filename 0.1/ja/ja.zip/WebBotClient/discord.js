function guilds_hide() {
    $("#guilds .card-header").html('<i class="fas fa-caret-right"></i> サーバー一覧');
    $("#guilds .card-header").attr("onclick","guilds_display();")
    $("#guilds .container").hide();
};

function guilds_display() {
    $("#guilds .card-header").html('<i class="fas fa-caret-down"></i> サーバー一覧');
    $("#guilds .card-header").attr("onclick","guilds_hide();")
    $("#guilds .container").show();
};

function channels_hide() {
    $("#channels .card-header").html('<i class="fas fa-caret-right"></i> チャンネル一覧');
    $("#channels .card-header").attr("onclick","channels_display();")
    $("#channels .container").hide();
};

function channels_display() {
    $("#channels .card-header").html('<i class="fas fa-caret-down"></i> チャンネル一覧');
    $("#channels .card-header").attr("onclick","channels_hide();")
    $("#channels .container").show();
};

function get_guilds() {
    var TOKEN = `Bot ${$("#input_token").val()}`;
    $.ajax({
        url:"https://discordapp.com/api/v6/users/@me/guilds",
        type:"GET",
        headers:{
            "Authorization":TOKEN,
            "Content-Type":"application/json"
        },
        dataType:"json",
        timespan:1000
    }).done(function(ajax_data) {
        $(".content form").html(`<input type="password" class="form-control is-valid" id="input_token" placeholder="BotのTOKENをここに入力してください。" value=${TOKEN.substr(4)} maxlength="59"><input type="button" class="btn btn-dark" onclick="get_token();" value="再接続">`);
        $(".content .invalid-feedback").css("display","none");
        var guild_data = [];
        for (var n in ajax_data) {
            var g = ajax_data[n];
            if (g["icon"] != null) {
                guild_data.push(`<div class="col"><div class="card" onclick="get_channels('${g['id']}','${TOKEN}');"><img class="card-img-top" src="https://cdn.discordapp.com/icons/${g['id']}/${g['icon']}.png"><div class="card-body"><p class="card-text">${g['name']}</p></div></div></div>`)
            } else {
                guild_data.push(`<div class="col"><div class="card" onclick="get_channels('${g['id']}','${TOKEN}');"><img class="card-img-top" src="discord.png"><div class="card-body"><p class="card-text">${g['name']}</p></div></div></div>`)
            };
        };
        $("#guilds").html(`<div class="card-header" onclick="guilds_hide();"><i class="fas fa-caret-down"></i> サーバー一覧</div><div class="container"><div class="row">${guild_data.join("")}</div></div>`);
    }).fail(function() {
        $(".content form").html(`<input type="password" class="form-control is-invalid" id="input_token" placeholder="BotのTOKENをここに入力してください。" value=${TOKEN.substr(4)} maxlength="59"><input type="button" class="btn btn-dark" onclick="get_token();" value="再接続">`);
        $(".content form").after('<div class="invalid-feedback">Botにアクセスできませんでした。</div>');
        $(".content .invalid-feedback").css("display","block");
    });
};

function get_channels(guild,TOKEN) {
    var text_channnel = '<svg width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M5.88657 21C5.57547 21 5.3399 20.7189 5.39427 20.4126L6.00001 17H2.59511C2.28449 17 2.04905 16.7198 2.10259 16.4138L2.27759 15.4138C2.31946 15.1746 2.52722 15 2.77011 15H6.35001L7.41001 9H4.00511C3.69449 9 3.45905 8.71977 3.51259 8.41381L3.68759 7.41381C3.72946 7.17456 3.93722 7 4.18011 7H7.76001L8.39677 3.41262C8.43914 3.17391 8.64664 3 8.88907 3H9.87344C10.1845 3 10.4201 3.28107 10.3657 3.58738L9.76001 7H15.76L16.3968 3.41262C16.4391 3.17391 16.6466 3 16.8891 3H17.8734C18.1845 3 18.4201 3.28107 18.3657 3.58738L17.76 7H21.1649C21.4755 7 21.711 7.28023 21.6574 7.58619L21.4824 8.58619C21.4406 8.82544 21.2328 9 20.9899 9H17.41L16.35 15H19.7549C20.0655 15 20.301 15.2802 20.2474 15.5862L20.0724 16.5862C20.0306 16.8254 19.8228 17 19.5799 17H16L15.3632 20.5874C15.3209 20.8261 15.1134 21 14.8709 21H13.8866C13.5755 21 13.3399 20.7189 13.3943 20.4126L14 17H8.00001L7.36325 20.5874C7.32088 20.8261 7.11337 21 6.87094 21H5.88657ZM9.41045 9L8.35045 15H14.3504L15.4104 9H9.41045Z"></path></svg>';
    var voice_channel = '<svg background="background-6FOJIb" aria-hidden="false" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M11.383 3.07904C11.009 2.92504 10.579 3.01004 10.293 3.29604L6 8.00204H3C2.45 8.00204 2 8.45304 2 9.00204V15.002C2 15.552 2.45 16.002 3 16.002H6L10.293 20.71C10.579 20.996 11.009 21.082 11.383 20.927C11.757 20.772 12 20.407 12 20.002V4.00204C12 3.59904 11.757 3.23204 11.383 3.07904ZM14 5.00195V7.00195C16.757 7.00195 19 9.24595 19 12.002C19 14.759 16.757 17.002 14 17.002V19.002C17.86 19.002 21 15.863 21 12.002C21 8.14295 17.86 5.00195 14 5.00195ZM14 9.00195C15.654 9.00195 17 10.349 17 12.002C17 13.657 15.654 15.002 14 15.002V13.002C14.551 13.002 15 12.553 15 12.002C15 11.451 14.551 11.002 14 11.002V9.00195Z"></path></svg>';
    var news_channel = '<svg background="background-6FOJIb" aria-hidden="false" width="24" height="24" viewBox="0 0 24 24"><path d="M3.9 8.26H2V15.2941H3.9V8.26Z" fill="currentColor"></path><path d="M19.1 4V5.12659L4.85 8.26447V18.1176C4.85 18.5496 5.1464 18.9252 5.5701 19.0315L9.3701 19.9727C9.4461 19.9906 9.524 20 9.6 20C9.89545 20 10.1776 19.8635 10.36 19.6235L12.7065 16.5242L19.1 17.9304V19.0588H21V4H19.1ZM9.2181 17.9944L6.75 17.3826V15.2113L10.6706 16.0753L9.2181 17.9944Z" fill="currentColor"></path></svg>';
    var store_channel = '<svg background="background-6FOJIb" aria-hidden="false" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M21.707 13.293l-11-11C10.519 2.105 10.266 2 10 2H3c-.553 0-1 .447-1 1v7c0 .266.105.519.293.707l11 11c.195.195.451.293.707.293s.512-.098.707-.293l7-7c.391-.391.391-1.023 0-1.414zM7 9c-1.106 0-2-.896-2-2 0-1.106.894-2 2-2 1.104 0 2 .894 2 2 0 1.104-.896 2-2 2z"></path></svg>';
    var category_channel = '<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path transform="translate(2.000000, 2.000000)" fill-rule="nonzero" fill="currentColor" d="M4,0 L4,3 L0,3 L0,0 L4,0 Z M12,4 L12,7 L8,7 L8,4 L12,4 Z M8,9 L12,9 L12,12 L8,12 L8,9.33333333 L8,9 Z M7,7 L3,7 L3,10 L7,10 L7,12 L3,12 L1,12 L1,4 L3,4 L3,5 L7,5 L7,7 Z"></path></svg>';
    guilds_hide();
    $.ajax({
        url:`https://discordapp.com/api/v6/guilds/${guild}/channels`,
        type:"GET",
        headers:{
            "Authorization":TOKEN,
            "Content-Type":"application/json"
        },
        dataType:"json",
        timespan:1000
    }).done(function(ajax_data) {
        var category_list = [];
        var category_data = {};
        var channel_list = [];
        var channel_data = [];
        for (var n in ajax_data) {
            var c = ajax_data[n];
            if (c["type"] == 4) {
                category_list.push(c);
                category_data[c["id"]] = []
            } else if (c["parent_id"] == null) {
                channel_list.push(c);
            };
        };
        for (var n in ajax_data) {
            var c = ajax_data[n];
            if (c["parent_id"] != null) {
                category_data[c["parent_id"]].push(c);
            };
        };
        for (var n in channel_list) {
            var c = channel_list[n];
            if (c["type"] == 2) {
                channel_data.push(`<div class="list-group-item list-group-item-action"><div class="h5">${voice_channel}${c["name"]}</div></div>`);
            } else if (c["type"] == 5) {
                channel_data.push(`<div class="list-group-item list-group-item-action pointer" onclick="get_messages('${c["id"]}','${TOKEN}');"><div class="h5">${news_channel}${c["name"]}</div></div>`);
            } else if (c["type"] == 6) {
                channel_data.push(`<div class="list-group-item list-group-item-action"><div class="h5">${store_channel}${c["name"]}</div></div>`);
            } else {
                channel_data.push(`<div class="list-group-item list-group-item-action pointer " onclick="get_messages('${c["id"]}','${TOKEN}');"><div class="h5">${text_channnel}${c["name"]}</div></div>`);
            };
        };
        for (var n in category_list) {
            var ca = category_list[n];
            channel_data.push(`<div class="list-group-item list-group-item-action"><div class="h5">${category_channel}${ca["name"]}</div></div>`);
            for (var n in category_data[ca["id"]]) {
                var ch = category_data[ca["id"]][n];
                if (c["type"] == 2) {
                    channel_data.push(`<div class="list-group-item list-group-item-action indent"><div class="h5">${voice_channel}${ch["name"]}</div></div>`);
                } else if (c["type"] == 5) {
                    channel_data.push(`<div class="list-group-item list-group-item-action pointer indent" onclick="get_messages('${ch["id"]}','${TOKEN}');"><div class="h5">${news_channel}${ch["name"]}</div></div>`);
                } else if (c["type"] == 6) {
                    channel_data.push(`<div class="list-group-item list-group-item-action indent"><div class="h5">${store_channel}${ch["name"]}</div></div>`);
                } else{
                    channel_data.push(`<div class="list-group-item list-group-item-action pointer indent" onclick="get_messages('${ch["id"]}','${TOKEN}');"><div class="h5">${text_channnel}${ch["name"]}</div></div>`);
                };
            };
        };
        $("#channels").html(`<div class="card-header" onclick="channels_hide();"><i class="fas fa-caret-down"></i> チャンネル一覧</div><div class="container"><div class="list-group">${channel_data.join("")}</div></div>`);
    });
};

function get_messages(cid,TOKEN) {
    channels_hide();
    var messages_el = document.getElementById('messages');
    messages_el.insertAdjacentHTML('beforeend','<input type="button" onclick="get_messages(TOKEN);" value="再読み込み>');
    var xhr = new XMLHttpRequest();
    xhr.onload = function() {
        let messages = JSON.parse(xhr.responseText);
        let glen = messages.length;
        for (var i = 0; i < glen; i++) {
            messages_el.insertAdjacentHTML('beforeend',message.author.username+':'+message.content);
            var icon = messages[i].icon;
        };
    };
    xhr.open('GET',"https://discordapp.com/api/v6/channels/"+cid+"/messages?limit=50");
    xhr.setRequestHeader("Authorization",TOKEN);
    xhr.setRequestHeader("Content-Type","application/json");
    xhr.send();
}